# Apex Store Intelligence — Brigade_Bangalore (STORE_BLR_002)

Raw CCTV footage → structured behavioural events → real-time store analytics API.
End-to-end pipeline for measuring the **offline store conversion rate** at the
Brigade Road Bangalore Purplle store.

```
CCTV clips → Detection (YOLO+ByteTrack) → Event JSONL → Ingest API → SQLite → Analytics → Dashboard
```

## Quickstart (5 commands)

```bash
git clone <repo-url> && cd store-intelligence       # 1
docker compose up --build -d                         # 2  API live on :8000
pip install -r requirements.txt                      # 3  (pipeline deps)
cd pipeline && ./run.sh synth                        # 4  generate + ingest events
curl localhost:8000/stores/STORE_BLR_002/metrics      # 5  see live metrics
```

That's it. `docker compose up` needs nothing beyond `git clone`. Synth mode
gives you a complete event stream against the real zone names so the API can be
validated before any video processing.

## Camera → clip mapping

`pipeline/store_layout.json` maps each clip to a camera role. Place your clips
in `./clips/` with these names (or update `clip_file` fields in the layout):

| Clip | Camera ID | Role |
|---|---|---|
| `CAM_3.mp4` | CAM_ENTRY_01 | Entry door (line at x=0.55, inbound=leftward) |
| `CAM_1.mp4` | CAM_FLOOR_SKINCARE | Top-wall skincare shelves (8 zones) |
| `CAM_2.mp4` | CAM_FLOOR_MAKEUP | Bottom-wall makeup shelves (8 zones) |
| `CAM_5.mp4` | CAM_BILLING_01 | Cash counter + accessories |
| `CAM_4.mp4` | CAM_BACKROOM_01 | Stockroom (staff-only, customer events excluded) |

Camera roles, the entry line position, and all 22 zone names come from the
embedded floor plan inside `Brigade_Road_-_Store_layout.xlsx` (extracted from
`xl/media/image1.png`).

## Running detection on the real clips

Uncomment the video deps in `requirements.txt` first:
```
ultralytics
opencv-python-headless
```
Then:
```bash
pip install ultralytics opencv-python-headless
cd pipeline
python detect.py --mode video --clips ../clips --out events.jsonl
```

YOLOv8n weights (`yolov8n.pt`, ~6 MB) auto-download on first run.

The combined run (detection + ingest):
```bash
./run.sh video ../clips
```
After it finishes, hit `/metrics`, `/funnel`, `/heatmap`, `/anomalies`.

## Live dashboard (Part E)

`detect.py --mode replay` streams a previously-emitted events file in
simulated real time. Generate once, replay at 30× to see the dashboard fill in:
```bash
python detect.py --mode synth --out events.jsonl --n 200
python detect.py --mode replay --replay events.jsonl --realtime --speed 30 \
  | xargs -I {} curl -s -X POST -H 'Content-Type: application/json' \
      -d '{"events":[{}]}' localhost:8000/events/ingest
```

While that runs, in another terminal:
```bash
watch -n 2 "curl -s localhost:8000/stores/STORE_BLR_002/metrics | python -m json.tool"
```

## Loading POS transactions

Conversion needs POS data. Mount your CSV and set `POS_CSV_PATH` in
`docker-compose.yml` to auto-load on startup. The loader is tolerant of both
the simple `store_id,transaction_id,timestamp,basket_value_inr` schema and the
rich Brigade export — it maps `invoice_number → transaction_id`,
`order_date + order_time → timestamp`, `total_amount → basket_value`. For the
supplied `Brigade_Bangalore_10_April_26.csv`, 101 line items collapse to 24
unique invoices via the `invoice_number` PRIMARY KEY.

## Endpoints

| Method | Path | Returns |
|---|---|---|
| POST | `/events/ingest` | Batch ingest (≤500), idempotent by `event_id`, partial success |
| GET | `/stores/{id}/metrics` | Unique visitors, conversion rate, dwell/zone, queue depth, abandonment |
| GET | `/stores/{id}/funnel` | Entry → Zone → Billing → Purchase, session-deduped |
| GET | `/stores/{id}/heatmap` | Zone frequency + dwell, normalised 0–100, `data_confidence` flag if <20 sessions |
| GET | `/stores/{id}/anomalies` | Queue spike / conversion drop / dead zone, with severity + suggested_action |
| GET | `/health` | Per-store last-event time + STALE_FEED warning at >10 min lag |

## Tests

```bash
pip install -r requirements.txt
python -m pytest tests/ --cov=app --cov-report=term-missing
```
14 tests passing, **82% statement coverage**. Covers idempotency,
partial-success ingest, staff exclusion, zero-purchase store, empty store,
re-entry funnel dedup, queue-spike anomaly, stale-feed health.

## Project layout

```
pipeline/   detect.py · tracker.py · emit.py · run.sh · store_layout.json   (Part A)
app/        main.py · models.py · ingestion.py · metrics.py · funnel.py · anomalies.py · health.py · storage.py   (Part B/C)
tests/      test_pipeline.py · test_metrics.py · test_anomalies.py   (prompt blocks at top)
docs/       DESIGN.md · CHOICES.md   (Part D)
docker-compose.yml · Dockerfile · requirements.txt
```

## Notes

- **Idempotent ingest:** re-sending the same payload reports `duplicates`, inserts nothing.
- **Graceful degradation:** DB down → HTTP 503 structured body, never a stack trace.
- **Structured logs:** one JSON line per request (`trace_id`, `store_id`, `endpoint`, `latency_ms`, `event_count`, `status_code`).
- See `docs/DESIGN.md` for architecture + AI-assisted decisions, `docs/CHOICES.md` for the three key trade-offs.
