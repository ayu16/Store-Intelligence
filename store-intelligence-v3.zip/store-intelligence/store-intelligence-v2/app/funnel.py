"""
Funnel + heatmap.

CRITICAL: the unit of analysis is the SESSION (visitor_id), not raw events.
Re-entries must not double-count a visitor. We collapse all events for a
visitor_id into one session and ask, per stage, "did this session reach it?".
"""
from __future__ import annotations

from datetime import datetime, timezone

from .models import FunnelResponse, FunnelStage, HeatmapResponse, HeatmapCell
from . import storage
from .metrics import _today_window, CONVERSION_WINDOW


def compute_funnel(store_id: str, now: datetime | None = None) -> FunnelResponse:
    start, end = _today_window(now)
    s_iso, e_iso = start.isoformat(), end.isoformat()

    rows = storage.query(
        """SELECT visitor_id, event_type, zone_id, timestamp FROM events
           WHERE store_id=? AND is_staff=0 AND timestamp BETWEEN ? AND ?""",
        (store_id, s_iso, e_iso),
    )

    sessions: dict[str, dict] = {}
    for r in rows:
        s = sessions.setdefault(r["visitor_id"], {
            "entered": False, "zone_visit": False, "billing": False,
            "billing_times": [],
        })
        et = r["event_type"]
        if et in ("ENTRY", "REENTRY"):
            s["entered"] = True
        if et in ("ZONE_ENTER", "ZONE_DWELL") and r["zone_id"]:
            s["zone_visit"] = True
        if et.startswith("BILLING") or (r["zone_id"] and "BILLING" in r["zone_id"].upper()):
            s["billing"] = True
            s["billing_times"].append(datetime.fromisoformat(r["timestamp"]))

    pos = storage.query(
        """SELECT timestamp FROM pos_transactions
           WHERE store_id=? AND timestamp BETWEEN ? AND ?""",
        (store_id, s_iso, e_iso),
    )
    pos_times = []
    for p in pos:
        ts = p["timestamp"].replace("Z", "+00:00") if "Z" in p["timestamp"] else p["timestamp"]
        try:
            pos_times.append(datetime.fromisoformat(ts))
        except ValueError:
            pass

    def purchased(billing_times: list[datetime]) -> bool:
        for bt in billing_times:
            bt_a = bt if bt.tzinfo else bt.replace(tzinfo=timezone.utc)
            for pt in pos_times:
                pt_a = pt if pt.tzinfo else pt.replace(tzinfo=timezone.utc)
                if 0 <= (pt_a - bt_a).total_seconds() <= CONVERSION_WINDOW.total_seconds():
                    return True
        return False

    n_entry = sum(1 for s in sessions.values() if s["entered"])
    n_zone = sum(1 for s in sessions.values() if s["entered"] and s["zone_visit"])
    n_billing = sum(1 for s in sessions.values() if s["billing"])
    n_purchase = sum(1 for s in sessions.values() if purchased(s["billing_times"]))

    counts = [("Entry", n_entry), ("Zone Visit", n_zone),
              ("Billing Queue", n_billing), ("Purchase", n_purchase)]

    stages: list[FunnelStage] = []
    prev = None
    for name, c in counts:
        if prev is None or prev == 0:
            drop = 0.0
        else:
            drop = round((prev - c) / prev * 100, 2)
        stages.append(FunnelStage(stage=name, count=c, drop_off_pct=drop))
        prev = c

    return FunnelResponse(store_id=store_id, stages=stages)


def compute_heatmap(store_id: str, now: datetime | None = None) -> HeatmapResponse:
    start, end = _today_window(now)
    s_iso, e_iso = start.isoformat(), end.isoformat()

    rows = storage.query(
        """SELECT zone_id, COUNT(DISTINCT visitor_id) AS freq,
                  AVG(dwell_ms) AS avg_dwell
           FROM events
           WHERE store_id=? AND is_staff=0 AND zone_id IS NOT NULL
             AND timestamp BETWEEN ? AND ?
           GROUP BY zone_id""",
        (store_id, s_iso, e_iso),
    )

    n_sessions = storage.query_one(
        """SELECT COUNT(DISTINCT visitor_id) AS n FROM events
           WHERE store_id=? AND is_staff=0 AND timestamp BETWEEN ? AND ?""",
        (store_id, s_iso, e_iso),
    )["n"]

    max_freq = max((r["freq"] for r in rows), default=0) or 1
    max_dwell = max((r["avg_dwell"] or 0 for r in rows), default=0) or 1

    cells = [
        HeatmapCell(
            zone_id=r["zone_id"],
            visit_frequency=round(r["freq"] / max_freq * 100, 2),
            avg_dwell=round((r["avg_dwell"] or 0) / max_dwell * 100, 2),
        )
        for r in rows
    ]

    return HeatmapResponse(
        store_id=store_id,
        cells=cells,
        data_confidence=n_sessions >= 20,
    )
