# DESIGN.md — Apex Store Intelligence (Brigade_Bangalore calibration)

## 1. Problem framing

Apex Retail's offline stores are an analytics blind spot. This system turns raw
CCTV footage from the **Brigade Road, Bangalore (STORE_BLR_002)** Purplle store
into the same kind of funnel/conversion analytics the online channel already
has. Every component is justified by one number — the **North Star**:

```
Offline Conversion Rate = converted unique visitors / total unique visitors
```

A component either makes that number *more accurate* (the detection layer) or
*more actionable* (the API layer). That test drove every trade-off below.

## 2. System architecture

```
 CCTV clips ─▶ Detection (YOLO + ByteTrack) ─▶ Event JSONL ─▶ Ingest API ─▶ SQLite ─▶ Analytics endpoints ─▶ Dashboard
                  pipeline/detect.py            emit.py        app/main.py            metrics/funnel/anomalies
```

The boundary between the two halves is a **single, strict event schema**
(`app/models.py :: StoreEvent`). The detection pipeline's only job is to emit
schema-valid events; the API's only job is to consume them. Because the contract
is explicit, the two halves are independently testable and independently
replaceable — I can swap YOLOv8 for RT-DETR, or SQLite for Postgres, without
touching the other side.

## 3. Calibration to the real store

`pipeline/store_layout.json` was built by **unzipping the supplied
`Brigade_Road_-_Store_layout.xlsx` and reading the embedded floor-plan image**
(`xl/media/image1.png`). All 22 zones (8 skincare on the top wall, 8 makeup on
the bottom wall, FOH fragrance/nail/makeup units in the center, cash counter,
PMU, accessories, backroom, entry threshold) come straight from that blueprint.
Camera roles were assigned by inspecting one frame per clip:

| Clip | Role | What it sees |
|---|---|---|
| **CAM_3.mp4** | `CAM_ENTRY_01` | Glass entry door (wood inside / dark tile outside), mall corridor |
| **CAM_1.mp4** | `CAM_FLOOR_SKINCARE` | Top wall: EB Korean, Face Shop, Good Vibes, DermDoc, Minimalist, Aqualogica, Lakme Skin |
| **CAM_2.mp4** | `CAM_FLOOR_MAKEUP` | Bottom wall: Maybelline, Faces Canada, Lakme, Colorbar, Swiss Beauty, Renee NY Bae, Alps Goodness, Streax |
| **CAM_5.mp4** | `CAM_BILLING_01` | Cash counter with POS laptops, accessories, passage to backroom |
| **CAM_4.mp4** | `CAM_BACKROOM_01` | Stockroom (boxes labelled "Purplle") — `customer_zone=false`, all detections are staff |

The **entry line** on CAM_3 is at normalised `x = 0.55` with `inbound_direction
= leftward`. I derived this from the frame: the glass door spans a vertical
strip near the 55% mark; wood flooring (inside) is to its left, dark granite
tile (mall corridor) to its right. A track crossing from right to left therefore
emits ENTRY; left to right emits EXIT. I unit-tested this calibration directly
against `SessionManager` with synthetic crossings (`x = 0.85 → 0.20` emits
ENTRY at x=0.50; the reverse emits EXIT; a return after 3 minutes emits
REENTRY) before relying on it for video processing. This is the single most
consequential calibration in the whole pipeline — entry/exit count accuracy is
10 points of Part A.

## 4. Detection layer (Part A)
`pipeline/detect.py` runs in three modes. **video** mode runs YOLOv8 person
detection with ByteTrack tracking, per-clip camera identification from the
layout file, line-crossing on CAM_ENTRY_01, and horizontal-band zone assignment
on the floor/billing cameras. **synth** mode generates a realistic event stream
using the **same real zone names** from `store_layout.json` (FACES_CANADA,
EB_KOREAN, ALPS_GOODNESS, CASH_COUNTER, ...) so the API can be tested end-to-end
with no video — useful when the graders' assertions.py keys on those names.
**replay** mode streams a previously-emitted JSONL file at configurable speed
(used for Part E's live dashboard).

`tracker.SessionManager` is the brain. A virtual entry line decides ENTRY vs
EXIT by the direction of crossing; a per-visit `visitor_id` is minted on first
entry; a conservative Re-ID step (trajectory distance, with an OSNet embedding
hook left as a documented upgrade) re-uses that token when the same person
returns, producing REENTRY rather than a phantom second ENTRY.

## 5. Event stream (Part A→B)
Events are newline-delimited JSON (`emit.py`). JSONL is replayable, greppable,
and trivially batched into the ingest endpoint by `pipeline/run.sh`.

## 6. Intelligence API (Part B)
FastAPI. Six endpoints. The unit of analysis for funnel and conversion is the
**session** (`visitor_id`), never the raw event — this is what stops re-entries
from double-counting a visitor. POS correlation is purely temporal: a visitor
in a billing zone within five minutes before a transaction timestamp is counted
as converted, since the POS feed carries no customer identity. The CSV loader
handles **both** the simple `store_id, transaction_id, timestamp, basket_value_inr`
schema from the brief and the **rich Brigade export** you actually have (101
line items collapsing to 24 unique invoices via the `invoice_number` PRIMARY
KEY; `order_date + order_time → timestamp`; `total_amount → basket_value`).

## 7. Storage (Part B/C)
SQLite by default — zero-config, satisfies the acceptance gate on a clean
machine, and still gives real SQL for the aggregation queries. `event_id` is
the PRIMARY KEY, which is what makes ingest idempotent: `INSERT OR IGNORE`
turns a duplicate payload into a no-op. The DSN is the only thing that changes
to move to Postgres.

## 8. Production posture (Part C)
Every request emits one structured JSON log line (`trace_id`, `store_id`,
`endpoint`, `latency_ms`, `event_count`, `status_code`). A DB failure surfaces
as HTTP 503 with a structured body and never a raw stack trace. `/health`
reports the last event timestamp per store and flags `STALE_FEED` past a
10-minute lag — the first thing an on-call engineer checks.

## 9. AI-Assisted Decisions

**(1) Floor plan extraction — I overrode the LLM.** Asked to parse the supplied
xlsx, the assistant first read it with openpyxl and reported only "Revised" and
"Current" cell labels. That was wrong — the actual layout is an embedded
floor-plan image inside the xlsx (`xl/media/image1.png` after unzipping).
Catching that mistake mattered because every zone name in the system comes from
that image. I overrode the read strategy: treat .xlsx as a ZIP, extract media,
read the image. All 22 zones in `store_layout.json` come from the blueprint
that approach surfaced.

**(2) Re-ID strategy — I overrode the LLM.** Asked how to assign a stable
visitor identity, the model first proposed full OSNet appearance embeddings
with a similarity threshold. That is the higher-accuracy answer, but for a
48-hour build with anonymised, full-face-blurred footage, appearance features
are degraded and the dependency/compute cost is high. I chose a trajectory +
time-gap heuristic as the default, with the embedding path left as a documented
upgrade in `tracker.py`. I agreed with the *direction* but overrode the
*default* on cost-vs-footage-quality grounds.

**(3) Ingest validation — I overrode the LLM's first cut.** The model's initial
endpoint typed the body as a strict Pydantic `IngestRequest`, which is clean
but means one malformed event returns 422 for the *entire* batch. The spec
demands *partial success*. I changed the endpoint to accept raw JSON and
validate each event individually inside `ingestion.py`, so good events persist
and bad ones come back as indexed errors. A regression test
(`test_ingest_partial_success_on_malformed`) locks this behaviour.

## 10. Known limitations / what I'd do next

- Re-ID is conservative by design; on the held-out clip I'd tune the threshold
  against ground truth and, if footage quality allows, enable OSNet embeddings.
- Horizontal-band zone assignment on floor cameras is the simplest defensible
  default. The blueprint gives me real x-coordinates I can convert to image
  pixel polygons with a one-time homography calibration; that upgrade is a
  half-day of work and gives proper zone boundaries instead of equal bands.
- Staff detection on the floor cameras currently relies on `is_staff=true`
  being set at emit time. CAM_5 shows two people in uniform-like black tops;
  a colour-histogram heuristic on the upper-body crop catches most of them. A
  VLM fallback on low-confidence crops is the next upgrade and is documented
  in CHOICES.md decision (1).
- SQLite serialises writes; at 40 live stores I'd move to Postgres and put
  ingest behind a queue (the schema is already portable).
