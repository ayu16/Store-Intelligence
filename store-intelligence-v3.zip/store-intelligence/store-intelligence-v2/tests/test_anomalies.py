# PROMPT: "Write pytest tests for an anomalies endpoint (queue spike, dead zone)
#   and a health endpoint that flags STALE_FEED when the last event is >10 min old."
# CHANGES MADE: Used a fixed 'now' injected into the logic functions rather than
#   sleeping, so the stale-feed test is deterministic and fast. Added a healthy
#   (non-stale) control case the model didn't include.
from __future__ import annotations

import importlib
import uuid
from datetime import datetime, timedelta, timezone

import pytest


@pytest.fixture()
def app_modules(tmp_path, monkeypatch):
    monkeypatch.setenv("DB_PATH", str(tmp_path / "test.db"))
    import app.storage as storage
    importlib.reload(storage)
    storage.init_db()
    import app.anomalies as anomalies
    import app.health as health
    importlib.reload(anomalies)
    importlib.reload(health)
    return storage, anomalies, health


def _row(**o):
    base = {
        "event_id": str(uuid.uuid4()),
        "store_id": "STORE_BLR_002",
        "camera_id": "CAM_BILLING_01",
        "visitor_id": "VIS_1",
        "event_type": "BILLING_QUEUE_JOIN",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "zone_id": "BILLING",
        "dwell_ms": 0,
        "is_staff": False,
        "confidence": 0.9,
        "queue_depth": 9,
        "sku_zone": "BILLING",
        "session_seq": 1,
    }
    base.update(o)
    return base


def test_queue_spike_detected(app_modules):
    storage, anomalies, _ = app_modules
    storage.insert_events([_row(queue_depth=12)])
    res = anomalies.detect_anomalies("STORE_BLR_002")
    types = [a.type for a in res.anomalies]
    assert "BILLING_QUEUE_SPIKE" in types
    spike = next(a for a in res.anomalies if a.type == "BILLING_QUEUE_SPIKE")
    assert spike.severity.value == "CRITICAL"
    assert spike.suggested_action  # must be non-empty


def test_no_anomaly_when_queue_small(app_modules):
    storage, anomalies, _ = app_modules
    storage.insert_events([_row(queue_depth=1)])
    res = anomalies.detect_anomalies("STORE_BLR_002")
    assert "BILLING_QUEUE_SPIKE" not in [a.type for a in res.anomalies]


def test_health_flags_stale_feed(app_modules):
    storage, _, health = app_modules
    old = (datetime.now(timezone.utc) - timedelta(minutes=30)).isoformat()
    storage.insert_events([_row(timestamp=old)])
    res = health.health_status()
    assert res.stores[0].stale is True
    assert res.status == "degraded"


def test_health_ok_when_fresh(app_modules):
    storage, _, health = app_modules
    fresh = datetime.now(timezone.utc).isoformat()
    storage.insert_events([_row(timestamp=fresh)])
    res = health.health_status()
    assert res.stores[0].stale is False
    assert res.status == "ok"
