# PROMPT: "Write pytest tests for a FastAPI event-ingestion endpoint that must
#   be idempotent by event_id, return partial success on malformed events, and
#   handle empty batches. Use a temp SQLite DB per test."
# CHANGES MADE: Added explicit duplicate-resubmission assertion (accepted then
#   duplicates), tightened the malformed-event case to check the structured
#   error index, and added a zero-event edge case. Pointed DB_PATH at a tmp file
#   via a fixture so tests never touch the real volume.
from __future__ import annotations

import importlib
import os
import uuid
from datetime import datetime, timezone

import pytest
from fastapi.testclient import TestClient


@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("DB_PATH", str(tmp_path / "test.db"))
    # Reimport storage + app so they pick up the patched DB_PATH.
    import app.storage as storage
    importlib.reload(storage)
    import app.main as main
    importlib.reload(main)
    main.storage.init_db()
    return TestClient(main.app)


def _event(**overrides) -> dict:
    base = {
        "event_id": str(uuid.uuid4()),
        "store_id": "STORE_BLR_002",
        "camera_id": "CAM_ENTRY_01",
        "visitor_id": "VIS_test01",
        "event_type": "ENTRY",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "zone_id": None,
        "dwell_ms": 0,
        "is_staff": False,
        "confidence": 0.9,
        "metadata": {"queue_depth": None, "sku_zone": None, "session_seq": 1},
    }
    base.update(overrides)
    return base


def test_ingest_accepts_valid_batch(client):
    r = client.post("/events/ingest", json={"events": [_event(), _event()]})
    assert r.status_code == 200
    body = r.json()
    assert body["accepted"] == 2
    assert body["rejected"] == 0


def test_ingest_is_idempotent(client):
    ev = _event()
    first = client.post("/events/ingest", json={"events": [ev]}).json()
    second = client.post("/events/ingest", json={"events": [ev]}).json()
    assert first["accepted"] == 1
    assert second["accepted"] == 0
    assert second["duplicates"] == 1


def test_ingest_partial_success_on_malformed(client):
    good = _event()
    bad = _event(confidence=5.0)  # out of [0,1] range -> rejected
    r = client.post("/events/ingest", json={"events": [good, bad]})
    assert r.status_code == 200
    body = r.json()
    assert body["accepted"] == 1
    assert body["rejected"] == 1
    assert body["errors"][0]["index"] == 1


def test_ingest_empty_batch(client):
    r = client.post("/events/ingest", json={"events": []})
    assert r.status_code == 200
    assert r.json()["accepted"] == 0


def test_ingest_rejects_oversized_batch(client):
    events = [_event() for _ in range(501)]
    r = client.post("/events/ingest", json={"events": events})
    assert r.status_code == 422  # exceeds 500-event limit
    assert r.json()["error"] == "batch_too_large"
