#!/usr/bin/env bash
# Run the detection pipeline and stream events into the API.
#
# Usage:
#   ./run.sh synth                 # generate synthetic events, ingest into API
#   ./run.sh video ./clips         # run real detection over clips, then ingest
set -euo pipefail

MODE="${1:-synth}"
CLIPS="${2:-./clips}"
STORE="${STORE_ID:-STORE_BLR_002}"
API="${API_URL:-http://localhost:8000}"
OUT="events.jsonl"

echo "[run] generating events (mode=$MODE) -> $OUT"
if [ "$MODE" = "synth" ]; then
  python detect.py --mode synth --store "$STORE" --out "$OUT"
else
  python detect.py --mode video --store "$STORE" --clips "$CLIPS" \
    --layout store_layout.json --out "$OUT"
fi

echo "[run] ingesting events into $API in batches of 500"
python - "$OUT" "$API" <<'PY'
import json, sys, urllib.request
path, api = sys.argv[1], sys.argv[2]
events = [json.loads(l) for l in open(path) if l.strip()]
for i in range(0, len(events), 500):
    batch = {"events": events[i:i+500]}
    req = urllib.request.Request(
        f"{api}/events/ingest",
        data=json.dumps(batch).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req) as r:
        print("[ingest]", r.status, r.read().decode()[:200])
print(f"[run] done: {len(events)} events")
PY

echo "[run] sample metrics:"
curl -s "$API/stores/$STORE/metrics" | python -m json.tool || true
