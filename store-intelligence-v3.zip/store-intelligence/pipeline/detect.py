"""
detect.py — main detection + tracking entrypoint.

Two modes:

  --mode video   : real CV pipeline. Runs YOLO person detection + ByteTrack on
                   each clip, classifies staff, maps boxes to zones via
                   store_layout.json, and emits schema-compliant events.
                   Requires: ultralytics, opencv-python (see requirements).

  --mode synth   : NO video required. Generates a realistic event stream
                   (entries, groups, dwell, queue, abandonment, re-entry, staff,
                   empty periods) so the whole system is runnable and testable
                   before the real clips arrive. Use this to validate the API.

Usage:
  python pipeline/detect.py --mode synth --store STORE_BLR_002 --out events.jsonl
  python pipeline/detect.py --mode video --clips ./clips --layout store_layout.json --out events.jsonl
"""
from __future__ import annotations

import argparse
import json
import random
from datetime import datetime, timedelta, timezone

from emit import EventEmitter, make_event
from tracker import SessionManager


# --------------------------------------------------------------------------- #
# Synthetic mode — produces a representative stream covering every edge case.  #
# --------------------------------------------------------------------------- #

ZONES = ["SKINCARE", "MAKEUP", "HAIRCARE", "FRAGRANCE", "BILLING"]


def run_synth(store_id: str, emitter: EventEmitter, n_visitors: int = 60,
              seed: int = 7) -> None:
    rng = random.Random(seed)
    t0 = datetime.now(timezone.utc).replace(hour=10, minute=0, second=0, microsecond=0)
    clock = t0
    visitor_n = 0

    def new_vid() -> str:
        nonlocal visitor_n
        visitor_n += 1
        return f"VIS_{visitor_n:05d}"

    for i in range(n_visitors):
        clock += timedelta(seconds=rng.randint(15, 90))

        # Empty-store period: occasionally jump the clock with no events.
        if rng.random() < 0.08:
            clock += timedelta(minutes=rng.randint(5, 10))

        is_staff = rng.random() < 0.12
        cam = "CAM_ENTRY_01"

        # Group entry: 1..4 people enter together.
        group_size = rng.choices([1, 2, 3, 4], weights=[70, 18, 8, 4])[0]
        group_id = f"G_{i}" if group_size > 1 else None

        for g in range(group_size):
            vid = new_vid()
            seq = 0

            def seqn() -> int:
                nonlocal seq
                seq += 1
                return seq

            emitter.emit(make_event(
                store_id=store_id, camera_id=cam, visitor_id=vid,
                event_type="ENTRY", timestamp=clock, confidence=rng.uniform(0.6, 0.98),
                is_staff=is_staff, session_seq=seqn(),
            ))

            if is_staff:
                # Staff roam all zones but should be excluded downstream.
                for z in rng.sample(ZONES, k=rng.randint(2, 4)):
                    clock += timedelta(seconds=rng.randint(20, 120))
                    emitter.emit(make_event(
                        store_id=store_id, camera_id="CAM_FLOOR_01", visitor_id=vid,
                        event_type="ZONE_ENTER", timestamp=clock, zone_id=z,
                        confidence=rng.uniform(0.7, 0.97), is_staff=True,
                        sku_zone=z, session_seq=seqn(),
                    ))
                emitter.emit(make_event(
                    store_id=store_id, camera_id=cam, visitor_id=vid,
                    event_type="EXIT", timestamp=clock + timedelta(seconds=30),
                    confidence=rng.uniform(0.6, 0.95), is_staff=True, session_seq=seqn(),
                ))
                continue

            # Customer journey through some zones.
            visited = rng.sample(ZONES[:-1], k=rng.randint(1, 3))
            for z in visited:
                clock += timedelta(seconds=rng.randint(10, 60))
                emitter.emit(make_event(
                    store_id=store_id, camera_id="CAM_FLOOR_01", visitor_id=vid,
                    event_type="ZONE_ENTER", timestamp=clock, zone_id=z,
                    confidence=rng.uniform(0.55, 0.97), sku_zone=z, session_seq=seqn(),
                ))
                dwell = rng.randint(30, 180)
                # Emit a ZONE_DWELL for every 30s of continued dwell.
                for d in range(30, dwell + 1, 30):
                    emitter.emit(make_event(
                        store_id=store_id, camera_id="CAM_FLOOR_01", visitor_id=vid,
                        event_type="ZONE_DWELL", timestamp=clock + timedelta(seconds=d),
                        zone_id=z, dwell_ms=d * 1000,
                        confidence=rng.uniform(0.55, 0.97), sku_zone=z, session_seq=seqn(),
                    ))
                clock += timedelta(seconds=dwell)

            # ~65% proceed to billing.
            if rng.random() < 0.65:
                queue_depth = rng.randint(0, 8)
                clock += timedelta(seconds=rng.randint(10, 40))
                if queue_depth > 0:
                    emitter.emit(make_event(
                        store_id=store_id, camera_id="CAM_BILLING_01", visitor_id=vid,
                        event_type="BILLING_QUEUE_JOIN", timestamp=clock,
                        zone_id="BILLING", queue_depth=queue_depth,
                        confidence=rng.uniform(0.6, 0.96), sku_zone="BILLING",
                        session_seq=seqn(),
                    ))
                # ~20% abandon the queue.
                if rng.random() < 0.20:
                    emitter.emit(make_event(
                        store_id=store_id, camera_id="CAM_BILLING_01", visitor_id=vid,
                        event_type="BILLING_QUEUE_ABANDON",
                        timestamp=clock + timedelta(seconds=rng.randint(60, 240)),
                        zone_id="BILLING", confidence=rng.uniform(0.6, 0.94),
                        sku_zone="BILLING", session_seq=seqn(),
                    ))

            emitter.emit(make_event(
                store_id=store_id, camera_id=cam, visitor_id=vid,
                event_type="EXIT", timestamp=clock + timedelta(seconds=rng.randint(20, 90)),
                confidence=rng.uniform(0.6, 0.96), session_seq=seqn(),
            ))

            # ~10% re-enter shortly after.
            if rng.random() < 0.10:
                clock += timedelta(minutes=rng.randint(1, 8))
                emitter.emit(make_event(
                    store_id=store_id, camera_id=cam, visitor_id=vid,
                    event_type="REENTRY", timestamp=clock,
                    confidence=rng.uniform(0.5, 0.9), session_seq=seqn(),
                ))


# --------------------------------------------------------------------------- #
# Video mode — real YOLO + ByteTrack. Skeleton wired to the tracker module.   #
# --------------------------------------------------------------------------- #

def run_video(clips_dir: str, layout_path: str, store_id: str,
              emitter: EventEmitter) -> None:  # pragma: no cover - needs GPU/clips
    try:
        from ultralytics import YOLO
        import cv2
    except ImportError as exc:
        raise SystemExit(
            "video mode needs `pip install ultralytics opencv-python`. "
            f"Original error: {exc}"
        )
    import os

    layout = json.load(open(layout_path)) if os.path.exists(layout_path) else {}
    model = YOLO("yolov8n.pt")  # person class = 0; swap for a larger model as needed
    sessions = SessionManager(line_x=0.5, inbound_is_rightward=True)

    for fname in sorted(os.listdir(clips_dir)):
        if not fname.lower().endswith((".mp4", ".avi", ".mov", ".mkv")):
            continue
        camera_id = _camera_from_filename(fname)
        cap = cv2.VideoCapture(os.path.join(clips_dir, fname))
        fps = cap.get(cv2.CAP_PROP_FPS) or 15.0
        frame_idx = 0
        clip_start = datetime.now(timezone.utc)  # replace with clip metadata

        # ByteTrack via ultralytics' built-in tracker.
        for result in model.track(source=os.path.join(clips_dir, fname),
                                   classes=[0], persist=True, stream=True,
                                   tracker="bytetrack.yaml", verbose=False):
            ts = clip_start + timedelta(seconds=frame_idx / fps)
            frame_idx += 1
            if result.boxes is None or result.boxes.id is None:
                continue
            w = result.orig_shape[1]
            for box, tid in zip(result.boxes.xywh, result.boxes.id):
                cx = float(box[0]) / w
                track_id = int(tid)
                for d in sessions.update(track_id, cx, ts):
                    emitter.emit(make_event(
                        store_id=store_id, camera_id=camera_id,
                        visitor_id=d["visitor_id"], event_type=d["event_type"],
                        timestamp=ts, confidence=0.8,  # use box conf in production
                        session_seq=d["session_seq"],
                    ))
        cap.release()


def _camera_from_filename(fname: str) -> str:
    f = fname.lower()
    if "entry" in f:
        return "CAM_ENTRY_01"
    if "bill" in f:
        return "CAM_BILLING_01"
    return "CAM_FLOOR_01"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["synth", "video"], default="synth")
    ap.add_argument("--store", default="STORE_BLR_002")
    ap.add_argument("--clips", default="./clips")
    ap.add_argument("--layout", default="store_layout.json")
    ap.add_argument("--out", default=None, help="JSONL output path (stdout if omitted)")
    ap.add_argument("--n", type=int, default=60, help="synth: number of visitors")
    args = ap.parse_args()

    with EventEmitter(args.out) as emitter:
        if args.mode == "synth":
            run_synth(args.store, emitter, n_visitors=args.n)
        else:
            run_video(args.clips, args.layout, args.store, emitter)


if __name__ == "__main__":
    main()
