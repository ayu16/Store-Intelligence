"""
emit.py — event schema construction + emission.

Single source of truth for building a schema-compliant event dict and writing
it to a JSONL stream (file or stdout). The API ingests exactly what this emits.
"""
from __future__ import annotations

import json
import sys
import uuid
from datetime import datetime, timezone
from typing import Optional, TextIO


def make_event(
    *,
    store_id: str,
    camera_id: str,
    visitor_id: str,
    event_type: str,
    timestamp: datetime,
    zone_id: Optional[str] = None,
    dwell_ms: int = 0,
    is_staff: bool = False,
    confidence: float,
    queue_depth: Optional[int] = None,
    sku_zone: Optional[str] = None,
    session_seq: Optional[int] = None,
) -> dict:
    """Build one schema-compliant event. Low-confidence events are NOT dropped
    here — calibration/flagging is the consumer's job, per the challenge."""
    if timestamp.tzinfo is None:
        timestamp = timestamp.replace(tzinfo=timezone.utc)
    return {
        "event_id": str(uuid.uuid4()),
        "store_id": store_id,
        "camera_id": camera_id,
        "visitor_id": visitor_id,
        "event_type": event_type,
        "timestamp": timestamp.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
        "zone_id": zone_id,
        "dwell_ms": dwell_ms,
        "is_staff": is_staff,
        "confidence": round(float(confidence), 4),
        "metadata": {
            "queue_depth": queue_depth,
            "sku_zone": sku_zone,
            "session_seq": session_seq,
        },
    }


class EventEmitter:
    """Writes events as JSONL. Use as a context manager."""

    def __init__(self, sink: Optional[str] = None):
        self._sink_path = sink
        self._fh: Optional[TextIO] = None

    def __enter__(self) -> "EventEmitter":
        self._fh = open(self._sink_path, "w", encoding="utf-8") if self._sink_path else sys.stdout
        return self

    def emit(self, event: dict) -> None:
        assert self._fh is not None
        self._fh.write(json.dumps(event) + "\n")
        self._fh.flush()

    def __exit__(self, *exc) -> None:
        if self._fh and self._fh is not sys.stdout:
            self._fh.close()
