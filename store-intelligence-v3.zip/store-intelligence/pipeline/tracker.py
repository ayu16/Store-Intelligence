"""
tracker.py — direction determination, session assignment, and Re-ID.

This module is detector-agnostic: it consumes per-frame detections
(bounding boxes + track ids from ByteTrack/DeepSORT) and produces the
behavioural decisions the event schema needs:

  * ENTRY vs EXIT   -> line-crossing on the entry camera
  * visitor_id      -> per-visit token; re-uses token on re-entry (Re-ID)
  * REENTRY         -> same physical person returns after an EXIT
  * group handling  -> count individuals, never collapse a group to one

The Re-ID strategy here is intentionally simple and explainable (trajectory +
time-gap heuristic) so it can be defended in the follow-up interview. Swap in
an OSNet embedding distance for higher accuracy — see CHOICES.md.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Optional


def _vid() -> str:
    return "VIS_" + uuid.uuid4().hex[:6]


@dataclass
class Track:
    track_id: int
    visitor_id: str
    first_seen: datetime
    last_seen: datetime
    last_cx: float
    inside: bool = False           # currently inside the store
    exited_at: Optional[datetime] = None
    session_seq: int = 0
    feature: Optional[list] = None  # optional Re-ID embedding


class SessionManager:
    """Assigns visitor_ids and decides ENTRY/EXIT/REENTRY using a virtual line.

    The entry line is a vertical x-coordinate (normalised 0..1). Crossing it
    left->right is inbound (ENTRY); right->left is outbound (EXIT). Flip
    `inbound_is_rightward` per camera mounting in store_layout.json.
    """

    REENTRY_WINDOW = timedelta(minutes=15)  # same person returning counts as re-entry

    def __init__(self, line_x: float = 0.5, inbound_is_rightward: bool = True):
        self.line_x = line_x
        self.inbound_is_rightward = inbound_is_rightward
        self.active: dict[int, Track] = {}      # track_id -> Track
        self.recent_exits: list[Track] = []     # for Re-ID re-entry matching

    def next_seq(self, track: Track) -> int:
        track.session_seq += 1
        return track.session_seq

    def _match_reentry(self, cx: float, ts: datetime,
                       feature: Optional[list]) -> Optional[Track]:
        """Find a recently-exited track that likely == this new appearance."""
        self.recent_exits = [
            t for t in self.recent_exits
            if t.exited_at and ts - t.exited_at <= self.REENTRY_WINDOW
        ]
        best = None
        best_score = 1e9
        for t in self.recent_exits:
            if feature is not None and t.feature is not None:
                score = _cosine_distance(feature, t.feature)
            else:
                score = abs(t.last_cx - cx)  # trajectory fallback
            if score < best_score:
                best_score, best = score, t
        # Thresholds are deliberately conservative; tune on the held-out clip.
        threshold = 0.35 if feature is not None else 0.15
        return best if best and best_score <= threshold else None

    def update(self, track_id: int, cx: float, ts: datetime,
               feature: Optional[list] = None) -> list[dict]:
        """Feed one detection. Returns a list of (event_type, visitor_id,
        session_seq) decisions triggered by this update."""
        decisions: list[dict] = []
        track = self.active.get(track_id)

        if track is None:
            # New track. Could be a fresh ENTRY or a REENTRY of a known person.
            reentry = self._match_reentry(cx, ts, feature)
            if reentry is not None:
                self.recent_exits.remove(reentry)
                reentry.track_id = track_id
                reentry.last_cx = cx
                reentry.last_seen = ts
                reentry.inside = True
                reentry.exited_at = None
                self.active[track_id] = reentry
                decisions.append({
                    "event_type": "REENTRY",
                    "visitor_id": reentry.visitor_id,
                    "session_seq": self.next_seq(reentry),
                })
                return decisions
            track = Track(track_id=track_id, visitor_id=_vid(),
                          first_seen=ts, last_seen=ts, last_cx=cx, feature=feature)
            self.active[track_id] = track
            # Defer ENTRY until the line is actually crossed.
            return decisions

        # Existing track: detect line crossing.
        crossed = (track.last_cx < self.line_x <= cx) or (track.last_cx >= self.line_x > cx)
        if crossed:
            rightward = cx > track.last_cx
            inbound = rightward == self.inbound_is_rightward
            if inbound and not track.inside:
                track.inside = True
                decisions.append({
                    "event_type": "ENTRY",
                    "visitor_id": track.visitor_id,
                    "session_seq": self.next_seq(track),
                })
            elif not inbound and track.inside:
                track.inside = False
                track.exited_at = ts
                self.recent_exits.append(track)
                decisions.append({
                    "event_type": "EXIT",
                    "visitor_id": track.visitor_id,
                    "session_seq": self.next_seq(track),
                })
        track.last_cx = cx
        track.last_seen = ts
        return decisions


def _cosine_distance(a: list, b: list) -> float:
    import math
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a)) or 1e-9
    nb = math.sqrt(sum(y * y for y in b)) or 1e-9
    return 1 - dot / (na * nb)
