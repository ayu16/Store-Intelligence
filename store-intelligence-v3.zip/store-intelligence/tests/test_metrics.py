# PROMPT: "Write pytest tests for store metrics and funnel endpoints. Cover:
#   staff exclusion, zero-purchase store, empty store returning zeros not nulls,
#   and re-entry not double-counting a visitor in the funnel."
# CHANGES MADE: Replaced the LLM's naive 'insert one event' setup with a small
#   scenario builder so each test reads as a story. Added the all-staff case
#   (metrics must be all zeros) which the model originally omitted.
from __future__ import annotations

import importlib
import uuid
from datetime import datetime, timezone

import pytest
from fastapi.testclient import TestClient


@pytest.fixture()
def ctx(tmp_path, monkeypatch):
    monkeypatch.setenv("DB_PATH", str(tmp_path / "test.db"))
    import app.storage as storage
    importlib.reload(storage)
    import app.main as main
    importlib.reload(main)
    main.storage.init_db()
    return TestClient(main.app), main.storage


def _ev(storage_mod, **o):
    base = {
        "event_id": str(uuid.uuid4()),
        "store_id": "STORE_BLR_002",
        "camera_id": "CAM_ENTRY_01",
        "visitor_id": "VIS_1",
        "event_type": "ENTRY",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "zone_id": None,
        "dwell_ms": 0,
        "is_staff": False,
        "confidence": 0.9,
        "metadata": {"queue_depth": None, "sku_zone": None, "session_seq": 1},
    }
    base.update(o)
    return base


def test_empty_store_returns_zeros_not_nulls(ctx):
    client, _ = ctx
    r = client.get("/stores/STORE_BLR_002/metrics")
    assert r.status_code == 200
    body = r.json()
    assert body["unique_visitors"] == 0
    assert body["conversion_rate"] == 0.0
    assert body["current_queue_depth"] == 0
    assert body["abandonment_rate"] == 0.0


def test_staff_excluded_from_unique_visitors(ctx):
    client, _ = ctx
    events = [
        _ev(client, visitor_id="VIS_customer", is_staff=False),
        _ev(client, visitor_id="VIS_staff", is_staff=True),
    ]
    # build proper dicts (helper needs storage but only uses defaults)
    events = [
        {**e} for e in [
            _ev(None, visitor_id="VIS_customer", is_staff=False),
            _ev(None, visitor_id="VIS_staff", is_staff=True),
        ]
    ]
    client.post("/events/ingest", json={"events": events})
    body = client.get("/stores/STORE_BLR_002/metrics").json()
    assert body["unique_visitors"] == 1  # staff not counted


def test_zero_purchase_store(ctx):
    client, _ = ctx
    events = [_ev(None, visitor_id=f"VIS_{i}") for i in range(3)]
    client.post("/events/ingest", json={"events": events})
    body = client.get("/stores/STORE_BLR_002/metrics").json()
    assert body["unique_visitors"] == 3
    assert body["conversions"] == 0
    assert body["conversion_rate"] == 0.0


def test_reentry_not_double_counted_in_funnel(ctx):
    client, _ = ctx
    vid = "VIS_returning"
    events = [
        _ev(None, visitor_id=vid, event_type="ENTRY"),
        _ev(None, visitor_id=vid, event_type="EXIT"),
        _ev(None, visitor_id=vid, event_type="REENTRY"),
    ]
    client.post("/events/ingest", json={"events": events})
    funnel = client.get("/stores/STORE_BLR_002/funnel").json()
    entry_stage = next(s for s in funnel["stages"] if s["stage"] == "Entry")
    assert entry_stage["count"] == 1  # one session, not two


def test_heatmap_low_confidence_flag(ctx):
    client, _ = ctx
    events = [
        _ev(None, visitor_id=f"VIS_{i}", event_type="ZONE_ENTER",
            zone_id="SKINCARE") for i in range(3)
    ]
    client.post("/events/ingest", json={"events": events})
    body = client.get("/stores/STORE_BLR_002/heatmap").json()
    assert body["data_confidence"] is False  # < 20 sessions


def test_metrics_window_override_finds_historical_events(ctx):
    """Events from a past date are zero under 'today' but non-zero with from/to."""
    client, _ = ctx
    # Insert an event dated 2026-04-10 (Brigade clip date)
    historical = _ev(None, visitor_id="VIS_april",
                     timestamp="2026-04-10T20:09:55+00:00")
    client.post("/events/ingest", json={"events": [historical]})

    # Default window (today): zero
    today_body = client.get("/stores/STORE_BLR_002/metrics").json()
    assert today_body["unique_visitors"] == 0

    # Explicit window covering April 10: one
    historical_body = client.get(
        "/stores/STORE_BLR_002/metrics"
        "?from=2026-04-10T00:00:00%2B00:00&to=2026-04-10T23:59:59%2B00:00"
    ).json()
    assert historical_body["unique_visitors"] == 1
