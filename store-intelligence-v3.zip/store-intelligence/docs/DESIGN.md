# DESIGN.md — Apex Store Intelligence

## 1. Problem framing

Apex Retail's offline stores are an analytics blind spot. This system turns raw
CCTV footage into the same kind of funnel/conversion analytics the online channel
already has. Every component is justified by one number — the **North Star**:

```
Offline Conversion Rate = converted unique visitors / total unique visitors
```

A component either makes that number *more accurate* (the detection layer) or
*more actionable* (the API layer). That test drove every trade-off below.

## 2. System architecture

```
 CCTV clips ─▶ Detection (YOLO + ByteTrack) ─▶ Event JSONL ─▶ Ingest API ─▶ SQLite ─▶ Analytics endpoints ─▶ Dashboard
                  pipeline/detect.py            emit.py        app/main.py            metrics/funnel/anomalies
```

The boundary between the two halves is a **single, strict event schema**
(`app/models.py :: StoreEvent`). The detection pipeline's only job is to emit
schema-valid events; the API's only job is to consume them. Because the contract
is explicit, the two halves are independently testable and independently
replaceable — I can swap YOLOv8 for RT-DETR, or SQLite for Postgres, without
touching the other side.

### Detection layer (Part A)
`pipeline/detect.py` runs in two modes. **video** mode runs YOLOv8 person
detection with ByteTrack tracking over each clip; `pipeline/tracker.py` converts
per-frame boxes into behavioural decisions: a virtual entry line determines
ENTRY vs EXIT by the direction of crossing, a per-visit `visitor_id` is minted on
first entry, and a conservative Re-ID step (trajectory distance, upgradeable to
OSNet embeddings) re-uses that token when the same person returns, producing
REENTRY rather than a phantom second ENTRY. **synth** mode emits a realistic
event stream with no video at all, so the whole system is runnable and the API is
fully testable before the graded clips arrive.

### Event stream (Part A→B)
Events are newline-delimited JSON (`emit.py`). JSONL is replayable, greppable,
and trivially batched into the ingest endpoint by `pipeline/run.sh`.

### Intelligence API (Part B)
FastAPI. Six endpoints. The unit of analysis for funnel and conversion is the
**session** (`visitor_id`), never the raw event — this is what stops re-entries
from double-counting a visitor. POS correlation is purely temporal: a visitor in
a billing zone within five minutes before a transaction timestamp is counted as
converted, since the POS feed carries no customer identity.

### Storage (Part B/C)
SQLite by default — zero-config, satisfies the acceptance gate on a clean
machine, and still gives real SQL for the aggregation queries. `event_id` is the
PRIMARY KEY, which is what makes ingest idempotent: `INSERT OR IGNORE` turns a
duplicate payload into a no-op. The DSN is the only thing that changes to move to
Postgres.

### Production posture (Part C)
Every request emits one structured JSON log line (`trace_id`, `store_id`,
`endpoint`, `latency_ms`, `event_count`, `status_code`). A DB failure surfaces as
HTTP 503 with a structured body and never a raw stack trace. `/health` reports
the last event timestamp per store and flags `STALE_FEED` past a 10-minute lag —
the first thing an on-call engineer checks.

## 3. AI-Assisted Decisions

**(1) Re-ID strategy — I overrode the LLM.** Asked how to assign a stable
visitor identity, the assistant first proposed full OSNet appearance embeddings
with a similarity threshold. That is the higher-accuracy answer, but for a
48-hour build with anonymised, full-face-blurred footage, appearance features are
degraded and the dependency/compute cost is high. I chose a trajectory +
time-gap heuristic as the default, with the embedding path left as a documented
upgrade in `tracker.py`. I agreed with the *direction* but overrode the *default*
on cost-vs-footage-quality grounds.

**(2) Ingest validation — I overrode the LLM's first cut.** The model's initial
endpoint typed the body as a strict Pydantic `IngestRequest`, which is clean but
means one malformed event returns 422 for the *entire* batch. The spec demands
*partial success*. I changed the endpoint to accept raw JSON and validate each
event individually inside `ingestion.py`, so good events persist and bad ones come
back as indexed errors. A regression test (`test_ingest_partial_success_on_malformed`)
locks this behaviour.

**(3) Anomaly thresholds — I agreed and constrained.** The assistant suggested
comparing today's conversion against a rolling 7-day average. I kept that but
added a guard: only flag a conversion drop when the baseline window has ≥20
sessions, so a quiet store doesn't generate noise. The "suggested_action" string
per anomaly was also an AI suggestion I kept — it makes the endpoint operator-
facing rather than just diagnostic.

## 4. Known limitations / what I'd do next

- Re-ID is conservative by design; on the held-out clip I'd tune the threshold
  against ground truth and, if footage quality allows, enable OSNet embeddings.
- SQLite serialises writes; at 40 live stores I'd move to Postgres and put ingest
  behind a queue (the schema is already portable).
- Cross-camera dedup (floor/entry overlap) is handled at the visitor_id level;
  a production build would add a homography-based spatial reconciliation step.
