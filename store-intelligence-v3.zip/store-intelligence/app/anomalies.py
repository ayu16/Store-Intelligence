"""
Anomaly detection: queue spike, conversion drop vs 7-day average, dead zone.
Each anomaly carries a severity and a suggested_action for the on-call operator.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from .models import AnomaliesResponse, Anomaly, Severity
from . import storage
from .metrics import compute_metrics

QUEUE_SPIKE_THRESHOLD = 5
DEAD_ZONE_MINUTES = 30
CONVERSION_DROP_PCT = 0.30  # 30% below 7-day avg => anomaly


def detect_anomalies(store_id: str, now: datetime | None = None) -> AnomaliesResponse:
    now = now or datetime.now(timezone.utc)
    anomalies: list[Anomaly] = []

    # 1. Queue spike -----------------------------------------------------------
    q = storage.query_one(
        """SELECT queue_depth, timestamp FROM events
           WHERE store_id=? AND queue_depth IS NOT NULL
           ORDER BY timestamp DESC LIMIT 1""",
        (store_id,),
    )
    if q and q["queue_depth"] and q["queue_depth"] >= QUEUE_SPIKE_THRESHOLD:
        depth = q["queue_depth"]
        sev = Severity.CRITICAL if depth >= QUEUE_SPIKE_THRESHOLD * 2 else Severity.WARN
        anomalies.append(Anomaly(
            type="BILLING_QUEUE_SPIKE",
            severity=sev,
            detail=f"Queue depth at {depth} (threshold {QUEUE_SPIKE_THRESHOLD}).",
            suggested_action="Open an additional billing counter or redirect staff to checkout.",
        ))

    # 2. Conversion drop vs 7-day average -------------------------------------
    today = compute_metrics(store_id, now).conversion_rate
    week_start = (now - timedelta(days=7)).isoformat()
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0).isoformat()
    hist = storage.query_one(
        """SELECT COUNT(DISTINCT visitor_id) AS v FROM events
           WHERE store_id=? AND is_staff=0
             AND timestamp BETWEEN ? AND ?""",
        (store_id, week_start, today_start),
    )
    # Only flag when we have a baseline to compare against.
    if hist and hist["v"] and hist["v"] >= 20:
        # Approximate 7-day avg conversion using POS vs visitors over the week.
        pos7 = storage.query_one(
            """SELECT COUNT(*) AS n FROM pos_transactions
               WHERE store_id=? AND timestamp BETWEEN ? AND ?""",
            (store_id, week_start, today_start),
        )["n"]
        baseline = pos7 / hist["v"] if hist["v"] else 0
        if baseline > 0 and today < baseline * (1 - CONVERSION_DROP_PCT):
            anomalies.append(Anomaly(
                type="CONVERSION_DROP",
                severity=Severity.WARN,
                detail=f"Today's conversion {today:.2%} is below 7-day avg {baseline:.2%}.",
                suggested_action="Check staffing, promotions, and whether the POS feed is delayed.",
            ))

    # 3. Dead zone: a known zone with no visits in the last 30 min -------------
    cutoff = (now - timedelta(minutes=DEAD_ZONE_MINUTES)).isoformat()
    known_zones = storage.query(
        "SELECT DISTINCT zone_id FROM events WHERE store_id=? AND zone_id IS NOT NULL",
        (store_id,),
    )
    for z in known_zones:
        recent = storage.query_one(
            """SELECT COUNT(*) AS n FROM events
               WHERE store_id=? AND zone_id=? AND timestamp >= ?""",
            (store_id, z["zone_id"], cutoff),
        )["n"]
        if recent == 0:
            anomalies.append(Anomaly(
                type="DEAD_ZONE",
                severity=Severity.INFO,
                detail=f"No visits to {z['zone_id']} in the last {DEAD_ZONE_MINUTES} min.",
                suggested_action=f"Verify camera coverage for {z['zone_id']} and check for display blockage.",
            ))

    return AnomaliesResponse(store_id=store_id, anomalies=anomalies)
