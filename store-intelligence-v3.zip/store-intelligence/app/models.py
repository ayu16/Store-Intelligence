"""
Pydantic models defining the canonical event schema and API payloads.

The event schema here is the contract between the detection pipeline (Part A)
and the Intelligence API (Part B). It matches the schema specified in the
challenge instruction sheet exactly.
"""
from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Optional, List
from uuid import UUID

from pydantic import BaseModel, Field, field_validator


class EventType(str, Enum):
    ENTRY = "ENTRY"
    EXIT = "EXIT"
    ZONE_ENTER = "ZONE_ENTER"
    ZONE_EXIT = "ZONE_EXIT"
    ZONE_DWELL = "ZONE_DWELL"
    BILLING_QUEUE_JOIN = "BILLING_QUEUE_JOIN"
    BILLING_QUEUE_ABANDON = "BILLING_QUEUE_ABANDON"
    REENTRY = "REENTRY"


class EventMetadata(BaseModel):
    queue_depth: Optional[int] = None
    sku_zone: Optional[str] = None
    session_seq: Optional[int] = None


class StoreEvent(BaseModel):
    """A single behavioural event emitted by the detection pipeline."""

    event_id: str = Field(..., description="Globally unique UUID-v4")
    store_id: str
    camera_id: str
    visitor_id: str = Field(..., description="Re-ID token, unique per visit session")
    event_type: EventType
    timestamp: datetime = Field(..., description="ISO-8601 UTC")
    zone_id: Optional[str] = Field(None, description="null for ENTRY/EXIT events")
    dwell_ms: int = 0
    is_staff: bool = False
    confidence: float = Field(..., ge=0.0, le=1.0)
    metadata: EventMetadata = Field(default_factory=EventMetadata)

    @field_validator("event_id")
    @classmethod
    def _validate_uuid(cls, v: str) -> str:
        # Accept any non-empty string but warn-validate UUID shape where possible.
        try:
            UUID(v)
        except (ValueError, AttributeError):
            # Pipeline-generated tokens that aren't strict UUIDs are tolerated,
            # but must still be unique. We do not hard-fail to keep ingest robust.
            if not v:
                raise ValueError("event_id must be non-empty")
        return v


class IngestRequest(BaseModel):
    events: List[StoreEvent] = Field(..., max_length=500)


class IngestItemError(BaseModel):
    index: int
    error: str


class IngestResponse(BaseModel):
    accepted: int
    duplicates: int
    rejected: int
    errors: List[IngestItemError] = Field(default_factory=list)


# ---- Analytics response models -------------------------------------------------

class ZoneDwell(BaseModel):
    zone_id: str
    avg_dwell_ms: float
    visits: int


class MetricsResponse(BaseModel):
    store_id: str
    window_start: datetime
    window_end: datetime
    unique_visitors: int
    conversions: int
    conversion_rate: float
    avg_dwell_by_zone: List[ZoneDwell]
    current_queue_depth: int
    abandonment_rate: float


class FunnelStage(BaseModel):
    stage: str
    count: int
    drop_off_pct: float


class FunnelResponse(BaseModel):
    store_id: str
    stages: List[FunnelStage]


class HeatmapCell(BaseModel):
    zone_id: str
    visit_frequency: float  # normalised 0-100
    avg_dwell: float        # normalised 0-100


class HeatmapResponse(BaseModel):
    store_id: str
    cells: List[HeatmapCell]
    data_confidence: bool  # False if < 20 sessions in window


class Severity(str, Enum):
    INFO = "INFO"
    WARN = "WARN"
    CRITICAL = "CRITICAL"


class Anomaly(BaseModel):
    type: str
    severity: Severity
    detail: str
    suggested_action: str


class AnomaliesResponse(BaseModel):
    store_id: str
    anomalies: List[Anomaly]


class StoreFeedStatus(BaseModel):
    store_id: str
    last_event_timestamp: Optional[datetime]
    stale: bool


class HealthResponse(BaseModel):
    status: str
    stores: List[StoreFeedStatus]
