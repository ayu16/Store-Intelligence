"""
Real-time metric computation.

North Star: conversion_rate = converted unique visitors / total unique visitors.
A visitor is "converted" if they were in the BILLING zone within the 5-minute
window BEFORE a POS transaction timestamp for the same store. Staff excluded
everywhere.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from .models import MetricsResponse, ZoneDwell
from . import storage

BILLING_ZONE_HINTS = ("BILLING", "CHECKOUT", "CASH", "QUEUE")
CONVERSION_WINDOW = timedelta(minutes=5)


def _today_window(now: datetime | None = None) -> tuple[datetime, datetime]:
    now = now or datetime.now(timezone.utc)
    start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    return start, now


def resolve_window(
    frm: datetime | None = None,
    to: datetime | None = None,
    now: datetime | None = None,
) -> tuple[datetime, datetime]:
    """Pick the analytics window. If `frm` and `to` are passed (e.g. from API
    query params), use them. Otherwise default to today's 00:00 → now.

    This is what lets the dashboard query historical clips dated 2026-04-10
    without changing the system clock or backdating events."""
    if frm and to:
        if frm.tzinfo is None:
            frm = frm.replace(tzinfo=timezone.utc)
        if to.tzinfo is None:
            to = to.replace(tzinfo=timezone.utc)
        return frm, to
    return _today_window(now)


def _is_billing(zone: str | None) -> bool:
    if not zone:
        return False
    z = zone.upper()
    return any(h in z for h in BILLING_ZONE_HINTS)


def compute_metrics(store_id: str, now: datetime | None = None,
                    frm: datetime | None = None,
                    to: datetime | None = None) -> MetricsResponse:
    start, end = resolve_window(frm, to, now)
    s_iso, e_iso = start.isoformat(), end.isoformat()

    unique_visitors = storage.query_one(
        """SELECT COUNT(DISTINCT visitor_id) AS n FROM events
           WHERE store_id=? AND is_staff=0 AND timestamp BETWEEN ? AND ?""",
        (store_id, s_iso, e_iso),
    )["n"]

    # Visitors present in a billing zone, with their timestamps.
    billing_rows = storage.query(
        """SELECT visitor_id, timestamp FROM events
           WHERE store_id=? AND is_staff=0 AND timestamp BETWEEN ? AND ?""",
        (store_id, s_iso, e_iso),
    )
    billing_presence: dict[str, list[datetime]] = {}
    for r in billing_rows:
        # presence considered for all events; conversion checks billing proximity
        billing_presence.setdefault(r["visitor_id"], []).append(
            datetime.fromisoformat(r["timestamp"])
        )

    # Only those who actually touched a billing zone are conversion-eligible.
    eligible_rows = storage.query(
        """SELECT visitor_id, timestamp FROM events
           WHERE store_id=? AND is_staff=0 AND timestamp BETWEEN ? AND ?
             AND (zone_id LIKE '%BILLING%' OR zone_id LIKE '%CHECKOUT%'
                  OR zone_id LIKE '%QUEUE%' OR event_type LIKE 'BILLING%')""",
        (store_id, s_iso, e_iso),
    )
    eligible: dict[str, list[datetime]] = {}
    for r in eligible_rows:
        eligible.setdefault(r["visitor_id"], []).append(
            datetime.fromisoformat(r["timestamp"])
        )

    pos = storage.query(
        """SELECT timestamp FROM pos_transactions
           WHERE store_id=? AND timestamp BETWEEN ? AND ?""",
        (store_id, s_iso, e_iso),
    )
    pos_times = [datetime.fromisoformat(p["timestamp"].replace("Z", "+00:00"))
                 if "Z" in p["timestamp"] else datetime.fromisoformat(p["timestamp"])
                 for p in pos]

    converted = set()
    for vid, times in eligible.items():
        for t in times:
            t_aware = t if t.tzinfo else t.replace(tzinfo=timezone.utc)
            for pt in pos_times:
                pt_aware = pt if pt.tzinfo else pt.replace(tzinfo=timezone.utc)
                if 0 <= (pt_aware - t_aware).total_seconds() <= CONVERSION_WINDOW.total_seconds():
                    converted.add(vid)
                    break
            if vid in converted:
                break

    conversions = len(converted)
    conversion_rate = (conversions / unique_visitors) if unique_visitors else 0.0

    # Average dwell per zone (from ZONE_DWELL events).
    dwell_rows = storage.query(
        """SELECT zone_id, AVG(dwell_ms) AS avg_dwell, COUNT(*) AS n
           FROM events
           WHERE store_id=? AND is_staff=0 AND zone_id IS NOT NULL
             AND timestamp BETWEEN ? AND ?
           GROUP BY zone_id""",
        (store_id, s_iso, e_iso),
    )
    avg_dwell = [
        ZoneDwell(zone_id=r["zone_id"], avg_dwell_ms=float(r["avg_dwell"] or 0),
                  visits=r["n"])
        for r in dwell_rows
    ]

    # Current queue depth = latest known queue_depth value.
    q = storage.query_one(
        """SELECT queue_depth FROM events
           WHERE store_id=? AND queue_depth IS NOT NULL
             AND timestamp BETWEEN ? AND ?
           ORDER BY timestamp DESC LIMIT 1""",
        (store_id, s_iso, e_iso),
    )
    current_queue_depth = (q["queue_depth"] if q and q["queue_depth"] is not None else 0)

    # Abandonment rate = abandons / (joins + abandons), guard against zero.
    joins = storage.query_one(
        """SELECT COUNT(*) AS n FROM events WHERE store_id=? AND is_staff=0
           AND event_type='BILLING_QUEUE_JOIN' AND timestamp BETWEEN ? AND ?""",
        (store_id, s_iso, e_iso),
    )["n"]
    abandons = storage.query_one(
        """SELECT COUNT(*) AS n FROM events WHERE store_id=? AND is_staff=0
           AND event_type='BILLING_QUEUE_ABANDON' AND timestamp BETWEEN ? AND ?""",
        (store_id, s_iso, e_iso),
    )["n"]
    denom = joins + abandons
    abandonment_rate = (abandons / denom) if denom else 0.0

    return MetricsResponse(
        store_id=store_id,
        window_start=start,
        window_end=end,
        unique_visitors=unique_visitors,
        conversions=conversions,
        conversion_rate=round(conversion_rate, 4),
        avg_dwell_by_zone=avg_dwell,
        current_queue_depth=current_queue_depth,
        abandonment_rate=round(abandonment_rate, 4),
    )
