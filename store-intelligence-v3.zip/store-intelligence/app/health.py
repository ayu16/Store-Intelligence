"""
Health: service status + last event timestamp per store. A feed is STALE if
its last event is more than 10 minutes behind 'now'. This is the first thing
an on-call engineer checks, so it must be accurate.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from .models import HealthResponse, StoreFeedStatus
from . import storage

STALE_THRESHOLD = timedelta(minutes=10)


def health_status(now: datetime | None = None) -> HealthResponse:
    now = now or datetime.now(timezone.utc)
    rows = storage.query(
        """SELECT store_id, MAX(timestamp) AS last_ts
           FROM events GROUP BY store_id"""
    )
    stores: list[StoreFeedStatus] = []
    any_stale = False
    for r in rows:
        last = datetime.fromisoformat(r["last_ts"]) if r["last_ts"] else None
        if last and last.tzinfo is None:
            last = last.replace(tzinfo=timezone.utc)
        stale = bool(last and (now - last) > STALE_THRESHOLD)
        any_stale = any_stale or stale
        stores.append(StoreFeedStatus(
            store_id=r["store_id"], last_event_timestamp=last, stale=stale,
        ))
    status = "degraded" if any_stale else "ok"
    return HealthResponse(status=status, stores=stores)
