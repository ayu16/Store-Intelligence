"""
Ingestion: validate a batch, store valid events idempotently, and report
partial success. Malformed individual events do not fail the whole batch.
"""
from __future__ import annotations

from typing import Any

from pydantic import ValidationError

from .models import StoreEvent, IngestResponse, IngestItemError
from . import storage


def ingest_batch(raw_events: list[dict[str, Any]]) -> IngestResponse:
    valid_rows: list[dict] = []
    errors: list[IngestItemError] = []

    for idx, raw in enumerate(raw_events):
        try:
            ev = StoreEvent.model_validate(raw)
        except ValidationError as exc:
            first = exc.errors()[0]
            loc = ".".join(str(p) for p in first.get("loc", []))
            errors.append(IngestItemError(index=idx, error=f"{loc}: {first.get('msg')}"))
            continue
        valid_rows.append(_to_row(ev))

    accepted, duplicates = storage.insert_events(valid_rows)

    return IngestResponse(
        accepted=accepted,
        duplicates=duplicates,
        rejected=len(errors),
        errors=errors,
    )


def _to_row(ev: StoreEvent) -> dict:
    return {
        "event_id": ev.event_id,
        "store_id": ev.store_id,
        "camera_id": ev.camera_id,
        "visitor_id": ev.visitor_id,
        "event_type": ev.event_type.value,
        "timestamp": ev.timestamp.isoformat(),
        "zone_id": ev.zone_id,
        "dwell_ms": ev.dwell_ms,
        "is_staff": ev.is_staff,
        "confidence": ev.confidence,
        "queue_depth": ev.metadata.queue_depth,
        "sku_zone": ev.metadata.sku_zone,
        "session_seq": ev.metadata.session_seq,
    }
