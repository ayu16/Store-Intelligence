"""
Storage layer. SQLite by default (zero-config, works in docker compose).

Design choice: SQLite keeps the acceptance gate trivial to satisfy on a clean
machine while still giving us real SQL for the analytics queries. Swap the
DSN for PostgreSQL by setting DATABASE_URL; the schema is portable.

Idempotency is enforced at the DB level: event_id is the PRIMARY KEY, so an
INSERT OR IGNORE makes re-ingesting the same payload a no-op.
"""
from __future__ import annotations

import json
import os
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime
from typing import Iterable, Optional

DB_PATH = os.environ.get("DB_PATH", "/data/store_intel.db")

_SCHEMA = """
CREATE TABLE IF NOT EXISTS events (
    event_id      TEXT PRIMARY KEY,
    store_id      TEXT NOT NULL,
    camera_id     TEXT NOT NULL,
    visitor_id    TEXT NOT NULL,
    event_type    TEXT NOT NULL,
    timestamp     TEXT NOT NULL,
    zone_id       TEXT,
    dwell_ms      INTEGER NOT NULL DEFAULT 0,
    is_staff      INTEGER NOT NULL DEFAULT 0,
    confidence    REAL NOT NULL,
    queue_depth   INTEGER,
    sku_zone      TEXT,
    session_seq   INTEGER
);
CREATE INDEX IF NOT EXISTS idx_events_store_ts ON events(store_id, timestamp);
CREATE INDEX IF NOT EXISTS idx_events_visitor  ON events(visitor_id);

CREATE TABLE IF NOT EXISTS pos_transactions (
    transaction_id TEXT PRIMARY KEY,
    store_id       TEXT NOT NULL,
    timestamp      TEXT NOT NULL,
    basket_value   REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_pos_store_ts ON pos_transactions(store_id, timestamp);
"""


class DatabaseUnavailable(Exception):
    """Raised when the DB cannot be reached; surfaces as HTTP 503."""


_local = threading.local()


def _ensure_dir() -> None:
    d = os.path.dirname(DB_PATH)
    if d and not os.path.exists(d):
        os.makedirs(d, exist_ok=True)


def init_db() -> None:
    _ensure_dir()
    with _connect() as conn:
        conn.executescript(_SCHEMA)
        conn.commit()


@contextmanager
def _connect():
    try:
        conn = sqlite3.connect(DB_PATH, timeout=5.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL;")
        yield conn
    except sqlite3.Error as exc:  # pragma: no cover - exercised via fault injection
        raise DatabaseUnavailable(str(exc)) from exc
    finally:
        try:
            conn.close()
        except Exception:
            pass


def insert_events(rows: Iterable[dict]) -> tuple[int, int]:
    """Insert events idempotently. Returns (accepted, duplicates)."""
    rows = list(rows)
    if not rows:
        return 0, 0
    accepted = 0
    duplicates = 0
    with _connect() as conn:
        for r in rows:
            cur = conn.execute(
                """INSERT OR IGNORE INTO events
                   (event_id, store_id, camera_id, visitor_id, event_type,
                    timestamp, zone_id, dwell_ms, is_staff, confidence,
                    queue_depth, sku_zone, session_seq)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    r["event_id"], r["store_id"], r["camera_id"], r["visitor_id"],
                    r["event_type"], r["timestamp"], r.get("zone_id"),
                    r.get("dwell_ms", 0), 1 if r.get("is_staff") else 0,
                    r["confidence"], r.get("queue_depth"), r.get("sku_zone"),
                    r.get("session_seq"),
                ),
            )
            if cur.rowcount == 1:
                accepted += 1
            else:
                duplicates += 1
        conn.commit()
    return accepted, duplicates


def load_pos_csv(path: str) -> int:
    """Load POS transactions. Tolerant of the rich Apex/Brigade CSV format:
    maps store_id, invoice_number->transaction_id, order_date+order_time->ts,
    total_amount->basket_value. Falls back to the simple 4-col schema."""
    import csv
    inserted = 0
    with _connect() as conn, open(path, newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh)
        cols = set(reader.fieldnames or [])
        for row in reader:
            if {"store_id", "transaction_id", "timestamp", "basket_value_inr"} <= cols:
                tid = row["transaction_id"]
                store = row["store_id"]
                ts = row["timestamp"]
                val = float(row["basket_value_inr"] or 0)
            else:
                tid = row.get("invoice_number") or row.get("order_id")
                store = row.get("store_id", "")
                date = (row.get("order_date") or "").strip()
                time = (row.get("order_time") or "").strip()
                ts = _to_iso(date, time)
                val = float(row.get("total_amount") or row.get("GMV") or 0)
            if not tid:
                continue
            cur = conn.execute(
                """INSERT OR IGNORE INTO pos_transactions
                   (transaction_id, store_id, timestamp, basket_value)
                   VALUES (?,?,?,?)""",
                (tid, store, ts, val),
            )
            inserted += cur.rowcount
        conn.commit()
    return inserted


def _to_iso(date: str, time: str) -> str:
    """Convert dd-mm-yyyy + HH:MM:SS to ISO-8601 UTC. Best-effort."""
    for fmt in ("%d-%m-%Y %H:%M:%S", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(f"{date} {time}", fmt).isoformat() + "Z"
        except ValueError:
            continue
    return f"{date}T{time}Z"


def query(sql: str, params: tuple = ()) -> list[sqlite3.Row]:
    with _connect() as conn:
        return list(conn.execute(sql, params).fetchall())


def query_one(sql: str, params: tuple = ()) -> Optional[sqlite3.Row]:
    rows = query(sql, params)
    return rows[0] if rows else None
