# Apex Store Intelligence

Raw CCTV footage → structured behavioural events → real-time store analytics API.
End-to-end pipeline for measuring the **offline store conversion rate**.

```
CCTV clips → Detection (YOLO+ByteTrack) → Event JSONL → Ingest API → SQLite → Analytics endpoints → Dashboard
```

## Quickstart (5 commands)

```bash
git clone <repo-url> && cd store-intelligence       # 1
docker compose up --build -d                         # 2  API live on :8000
cd pipeline && pip install -r ../requirements.txt    # 3  (pipeline deps)
./run.sh synth                                        # 4  generate + ingest events
curl localhost:8000/stores/STORE_BLR_002/metrics      # 5  see live metrics
```

That's it. `docker compose up` needs nothing beyond `git clone`. The API comes up
empty (zero traffic handled gracefully); step 4 feeds it events.

## Running detection against the real clips

Synthetic mode (no video, for validating the API):
```bash
python pipeline/detect.py --mode synth --store STORE_BLR_002 --out events.jsonl
```

Real CV mode (needs the clips + the video deps — uncomment them in
`requirements.txt` first: `ultralytics`, `opencv-python-headless`):
```bash
python pipeline/detect.py --mode video \
  --clips ./clips --layout store_layout.json \
  --store STORE_BLR_002 --out events.jsonl
```

`run.sh` does detection **and** ingestion in one go:
```bash
./run.sh synth          # or:  ./run.sh video ./clips
```
Output JSONL lands in `events.jsonl`; the script batches it (≤500/req) into
`POST /events/ingest`.

## Loading POS transactions

Conversion needs POS data. Mount your CSV and set `POS_CSV_PATH` in
`docker-compose.yml` to auto-load on startup. The loader is tolerant of both the
simple `store_id,transaction_id,timestamp,basket_value_inr` schema and the rich
Apex/Brigade export (maps `invoice_number→transaction_id`,
`order_date+order_time→timestamp`, `total_amount→basket_value`).

## Endpoints

| Method | Path | Returns |
|---|---|---|
| POST | `/events/ingest` | Batch ingest (≤500), idempotent by `event_id`, partial success |
| GET | `/stores/{id}/metrics` | Unique visitors, conversion rate, dwell/zone, queue depth, abandonment |
| GET | `/stores/{id}/funnel` | Entry → Zone → Billing → Purchase, session-deduped |
| GET | `/stores/{id}/heatmap` | Zone frequency + dwell, normalised 0–100, confidence flag |
| GET | `/stores/{id}/anomalies` | Queue spike / conversion drop / dead zone, with severity + action |
| GET | `/health` | Per-store last-event time + STALE_FEED warning |

## Tests

```bash
pip install -r requirements.txt
python -m pytest tests/ --cov=app --cov-report=term-missing
```
Covers idempotency, partial-success ingest, staff exclusion, zero-purchase store,
empty store, re-entry funnel dedup, queue-spike anomaly, stale-feed health.
Statement coverage > 70%.

## Project layout

```
pipeline/   detect.py · tracker.py · emit.py · run.sh   (Part A)
app/        main.py · models.py · ingestion.py · metrics.py · funnel.py · anomalies.py · health.py · storage.py  (Part B/C)
tests/      test_pipeline.py · test_metrics.py · test_anomalies.py   (prompt blocks at top)
docs/       DESIGN.md · CHOICES.md   (Part D)
docker-compose.yml · Dockerfile · requirements.txt
```

## Notes

- **Idempotent ingest:** re-sending the same payload reports `duplicates`, inserts nothing.
- **Graceful degradation:** DB down → HTTP 503 structured body, never a stack trace.
- **Structured logs:** one JSON line per request (`trace_id`, `store_id`, `endpoint`, `latency_ms`, `event_count`, `status_code`).
- See `docs/DESIGN.md` for architecture + AI-assisted decisions, `docs/CHOICES.md` for the three key trade-offs.

## Live dashboard (Part E)

A standalone ops dashboard (`dashboard/index.html`) polls the API every 2 seconds and shows conversion rate, unique visitors, the funnel, queue depth, zone engagement, and live anomalies — each tile flashes amber when its value changes.

Three-terminal demo:

```bash
# Terminal 1 — API (CORS enabled so the browser can call it)
uvicorn app.main:app --port 8000

# Terminal 2 — generate a stream, then replay it into the API fast-forward
cd pipeline
python detect.py --mode synth --out events.jsonl --n 200
python replay_to_api.py --events events.jsonl --speed 60

# Terminal 3 — open the dashboard
#   double-click dashboard/index.html  (Windows: start dashboard\index.html)
```

`--speed 60` replays one sim-hour per real minute; watch the tiles climb. The dashboard's FROM/TO fields default to the Brigade clip date (2026-04-10); for synth data (dated today) adjust them to today's date. Conversion rate stays 0 until POS data is loaded (see the POS section above) — that is by design, not a bug.
