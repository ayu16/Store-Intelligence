"""
FastAPI entrypoint. Wires up all six endpoints, structured request logging,
and graceful degradation (DB down -> 503 with structured body, never a raw
stack trace).
"""
from __future__ import annotations

import json
import logging
import os
import sys
import time
import uuid
from datetime import datetime

from fastapi import FastAPI, Request, Query
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware

from . import storage
from .models import (
    IngestRequest, IngestResponse, MetricsResponse, FunnelResponse,
    HeatmapResponse, AnomaliesResponse, HealthResponse,
)
from .ingestion import ingest_batch
from .metrics import compute_metrics
from .funnel import compute_funnel, compute_heatmap
from .anomalies import detect_anomalies
from .health import health_status
from .storage import DatabaseUnavailable

# --- Structured logging -------------------------------------------------------

logger = logging.getLogger("store_intel")
_handler = logging.StreamHandler(sys.stdout)
_handler.setFormatter(logging.Formatter("%(message)s"))
logger.addHandler(_handler)
logger.setLevel(logging.INFO)


def log_event(**fields) -> None:
    logger.info(json.dumps(fields, default=str))


app = FastAPI(title="Apex Store Intelligence API", version="1.0.0")

# CORS so the local dashboard (file:// or any localhost port) can call the API.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def _startup() -> None:
    storage.init_db()
    # Optionally auto-load POS data if a path is provided.
    pos_path = os.environ.get("POS_CSV_PATH")
    if pos_path and os.path.exists(pos_path):
        try:
            n = storage.load_pos_csv(pos_path)
            log_event(event="pos_loaded", rows=n, path=pos_path)
        except Exception as exc:  # pragma: no cover
            log_event(event="pos_load_failed", error=str(exc))


@app.middleware("http")
async def structured_logging(request: Request, call_next):
    trace_id = request.headers.get("x-trace-id", str(uuid.uuid4()))
    start = time.perf_counter()
    request.state.trace_id = trace_id
    request.state.event_count = 0
    try:
        response = await call_next(request)
    except DatabaseUnavailable as exc:
        latency = (time.perf_counter() - start) * 1000
        log_event(trace_id=trace_id, endpoint=request.url.path,
                  status_code=503, latency_ms=round(latency, 2), error=str(exc))
        return JSONResponse(
            status_code=503,
            content={"error": "database_unavailable",
                     "detail": "The storage backend is temporarily unavailable.",
                     "trace_id": trace_id},
        )
    except Exception as exc:  # no raw stack traces in responses
        latency = (time.perf_counter() - start) * 1000
        log_event(trace_id=trace_id, endpoint=request.url.path,
                  status_code=500, latency_ms=round(latency, 2), error=str(exc))
        return JSONResponse(
            status_code=500,
            content={"error": "internal_error", "trace_id": trace_id},
        )
    latency = (time.perf_counter() - start) * 1000
    store_id = request.path_params.get("id") if hasattr(request, "path_params") else None
    log_event(trace_id=trace_id, store_id=store_id, endpoint=request.url.path,
              latency_ms=round(latency, 2),
              event_count=getattr(request.state, "event_count", 0),
              status_code=response.status_code)
    response.headers["x-trace-id"] = trace_id
    return response


# --- Endpoints ----------------------------------------------------------------

@app.post("/events/ingest", response_model=IngestResponse)
async def ingest(request: Request):
    # Accept the batch as raw JSON (not a strict model) so a single malformed
    # event does not fail the whole batch. Per-event validation + partial
    # success is handled in ingest_batch.
    payload = await request.json()
    raw = payload.get("events", []) if isinstance(payload, dict) else []
    if len(raw) > 500:
        return JSONResponse(
            status_code=422,
            content={"error": "batch_too_large",
                     "detail": "Maximum 500 events per batch.",
                     "trace_id": getattr(request.state, "trace_id", None)},
        )
    request.state.event_count = len(raw)
    return ingest_batch(raw)


@app.get("/stores/{id}/metrics", response_model=MetricsResponse)
async def metrics(id: str,
                  frm: datetime | None = Query(None, alias="from"),
                  to: datetime | None = Query(None)):
    return compute_metrics(id, frm=frm, to=to)


@app.get("/stores/{id}/funnel", response_model=FunnelResponse)
async def funnel(id: str,
                 frm: datetime | None = Query(None, alias="from"),
                 to: datetime | None = Query(None)):
    return compute_funnel(id, frm=frm, to=to)


@app.get("/stores/{id}/heatmap", response_model=HeatmapResponse)
async def heatmap(id: str,
                  frm: datetime | None = Query(None, alias="from"),
                  to: datetime | None = Query(None)):
    return compute_heatmap(id, frm=frm, to=to)


@app.get("/stores/{id}/anomalies", response_model=AnomaliesResponse)
async def anomalies(id: str):
    return detect_anomalies(id)


@app.get("/health", response_model=HealthResponse)
async def health():
    return health_status()
