"""
replay_to_api.py — drive the live dashboard (Part E).

Reads an events.jsonl file and POSTs events to the running API in small batches,
pacing them by their real timestamps divided by --speed. Watch the dashboard
fill in as this runs.

Usage:
  # 1. start the API:        uvicorn app.main:app --port 8000
  # 2. generate events:      python detect.py --mode synth --out events.jsonl --n 200
  # 3. open dashboard:       dashboard/index.html  (double-click)
  # 4. run this:             python replay_to_api.py --events events.jsonl --speed 60

At --speed 60, one hour of store activity replays in one minute.
"""
from __future__ import annotations

import argparse
import json
import time
import urllib.request
from datetime import datetime


def post_batch(api: str, events: list[dict]) -> None:
    req = urllib.request.Request(
        f"{api}/events/ingest",
        data=json.dumps({"events": events}).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=5) as r:
            body = json.loads(r.read().decode())
            print(f"  ingested batch: accepted={body['accepted']} "
                  f"dupes={body['duplicates']} rejected={body['rejected']}", flush=True)
    except Exception as e:
        print(f"  [warn] ingest failed: {e}", flush=True)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--events", required=True)
    ap.add_argument("--api", default="http://localhost:8000")
    ap.add_argument("--speed", type=float, default=60.0,
                    help="time compression: 60 = 1 sim-hour per real minute")
    ap.add_argument("--batch", type=int, default=10,
                    help="events per POST")
    args = ap.parse_args()

    events = [json.loads(l) for l in open(args.events) if l.strip()]
    events.sort(key=lambda e: e["timestamp"])
    print(f"replaying {len(events)} events at {args.speed}x into {args.api}", flush=True)

    buf: list[dict] = []
    prev_ts: datetime | None = None

    for ev in events:
        cur = datetime.fromisoformat(ev["timestamp"].replace("Z", "+00:00"))
        if prev_ts is not None:
            gap = (cur - prev_ts).total_seconds() / args.speed
            if gap > 0:
                # Flush what we have before sleeping so the dashboard updates live.
                if buf:
                    post_batch(args.api, buf)
                    buf = []
                time.sleep(min(gap, 3.0))
        prev_ts = cur
        buf.append(ev)
        if len(buf) >= args.batch:
            post_batch(args.api, buf)
            buf = []

    if buf:
        post_batch(args.api, buf)
    print("replay complete.", flush=True)


if __name__ == "__main__":
    main()
