"""
detect.py — calibrated detection + tracking for Brigade_Bangalore (STORE_BLR_002).

Reads store_layout.json to map each clip -> camera_id, role, covered zones, and
the entry-line geometry. Runs YOLOv8 + ByteTrack. CPU-tuned (imgsz=480,
vid_stride=5) so a clip processes in a couple of minutes instead of 30+.

Modes:
  --mode synth   : no video; emits a realistic stream using REAL zone names.
  --mode video   : YOLOv8 + ByteTrack on each clip in --clips.
  --mode replay  : stream an existing events.jsonl (for the Part E dashboard).

Usage:
  python detect.py --mode video  --clips ..\\clips --out events.jsonl
  python detect.py --mode synth  --out events.jsonl
"""
from __future__ import annotations

import argparse
import json
import os
import random
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from emit import EventEmitter, make_event
from tracker import SessionManager

# CPU speed knobs. Lower imgsz / higher stride = faster, coarser.
INFER_IMGSZ = 480
VID_STRIDE = 5
YOLO_CONF = 0.35
CLIP_START = datetime(2026, 4, 10, 20, 9, 55, tzinfo=timezone.utc)


def load_layout(path: str = "store_layout.json") -> dict:
    p = Path(path)
    if not p.is_absolute():
        here = Path(__file__).parent / path
        p = here if here.exists() else Path(path)
    return json.loads(p.read_text())


def camera_for_clip(layout: dict, filename: str) -> dict | None:
    base = Path(filename).name.lower().replace("_small", "")
    for cam in layout["cameras"]:
        cf = cam["clip_file"].lower()
        if cf == base or cf.replace(".mp4", "") in base:
            return cam
    return None


# ---------------- synth mode ----------------

def run_synth(layout, emitter, store_id, n_visitors=60, seed=7):
    rng = random.Random(seed)
    skincare = [z["zone_id"] for z in layout["zones"] if z.get("category") == "skincare"]
    makeup = [z["zone_id"] for z in layout["zones"] if z.get("category") == "makeup"]
    billing = layout["billing_zones"][0]
    clock = datetime.now(timezone.utc).replace(hour=10, minute=0, second=0, microsecond=0)
    vn = 0
    def nv():
        nonlocal vn; vn += 1; return f"VIS_{vn:05d}"
    for i in range(n_visitors):
        clock += timedelta(seconds=rng.randint(15, 90))
        if rng.random() < 0.08:
            clock += timedelta(minutes=rng.randint(5, 10))
        staff = rng.random() < 0.12
        for _ in range(rng.choices([1,2,3,4], weights=[70,18,8,4])[0]):
            vid = nv(); seq = 0
            def sq():
                nonlocal seq; seq += 1; return seq
            emitter.emit(make_event(store_id=store_id, camera_id="CAM_ENTRY_01",
                visitor_id=vid, event_type="ENTRY", timestamp=clock, is_staff=staff,
                confidence=rng.uniform(0.6,0.98), session_seq=sq()))
            if staff:
                for z in rng.sample(skincare+makeup+["BACKROOM"], k=rng.randint(3,5)):
                    clock += timedelta(seconds=rng.randint(20,120))
                    cam = "CAM_BACKROOM_01" if z=="BACKROOM" else ("CAM_FLOOR_MAKEUP" if z in makeup else "CAM_FLOOR_SKINCARE")
                    emitter.emit(make_event(store_id=store_id, camera_id=cam, visitor_id=vid,
                        event_type="ZONE_ENTER", timestamp=clock, zone_id=z, is_staff=True,
                        confidence=rng.uniform(0.7,0.97), sku_zone=z, session_seq=sq()))
                emitter.emit(make_event(store_id=store_id, camera_id="CAM_ENTRY_01", visitor_id=vid,
                    event_type="EXIT", timestamp=clock+timedelta(seconds=30), is_staff=True,
                    confidence=rng.uniform(0.6,0.95), session_seq=sq()))
                continue
            visited = rng.sample(skincare, k=rng.randint(0,2)) + rng.sample(makeup, k=rng.randint(0,2))
            visited = visited or [rng.choice(skincare+makeup)]
            for z in visited:
                cam = "CAM_FLOOR_MAKEUP" if z in makeup else "CAM_FLOOR_SKINCARE"
                clock += timedelta(seconds=rng.randint(10,60))
                emitter.emit(make_event(store_id=store_id, camera_id=cam, visitor_id=vid,
                    event_type="ZONE_ENTER", timestamp=clock, zone_id=z,
                    confidence=rng.uniform(0.55,0.97), sku_zone=z, session_seq=sq()))
                dwell = rng.randint(30,180)
                for d in range(30, dwell+1, 30):
                    emitter.emit(make_event(store_id=store_id, camera_id=cam, visitor_id=vid,
                        event_type="ZONE_DWELL", timestamp=clock+timedelta(seconds=d),
                        zone_id=z, dwell_ms=d*1000, confidence=rng.uniform(0.55,0.97),
                        sku_zone=z, session_seq=sq()))
                clock += timedelta(seconds=dwell)
            if rng.random() < 0.65:
                qd = rng.randint(0,8); clock += timedelta(seconds=rng.randint(10,40))
                if qd > 0:
                    emitter.emit(make_event(store_id=store_id, camera_id="CAM_BILLING_01",
                        visitor_id=vid, event_type="BILLING_QUEUE_JOIN", timestamp=clock,
                        zone_id=billing, queue_depth=qd, confidence=rng.uniform(0.6,0.96),
                        sku_zone=billing, session_seq=sq()))
                if rng.random() < 0.20:
                    emitter.emit(make_event(store_id=store_id, camera_id="CAM_BILLING_01",
                        visitor_id=vid, event_type="BILLING_QUEUE_ABANDON",
                        timestamp=clock+timedelta(seconds=rng.randint(60,240)), zone_id=billing,
                        confidence=rng.uniform(0.6,0.94), sku_zone=billing, session_seq=sq()))
            emitter.emit(make_event(store_id=store_id, camera_id="CAM_ENTRY_01", visitor_id=vid,
                event_type="EXIT", timestamp=clock+timedelta(seconds=rng.randint(20,90)),
                confidence=rng.uniform(0.6,0.96), session_seq=sq()))
            if rng.random() < 0.10:
                clock += timedelta(minutes=rng.randint(1,8))
                emitter.emit(make_event(store_id=store_id, camera_id="CAM_ENTRY_01", visitor_id=vid,
                    event_type="REENTRY", timestamp=clock, confidence=rng.uniform(0.5,0.9),
                    session_seq=sq()))


# ---------------- video mode ----------------

def run_video(clips_dir, layout, store_id, emitter):
    try:
        from ultralytics import YOLO
    except ImportError:
        raise SystemExit("video mode needs: pip install ultralytics opencv-python-headless")
    model = YOLO("yolov8n.pt")
    for fname in sorted(os.listdir(clips_dir)):
        if not fname.lower().endswith((".mp4",".avi",".mov",".mkv")):
            continue
        cam = camera_for_clip(layout, fname)
        if not cam:
            print(f"[detect] SKIP {fname}: no camera mapped in layout", flush=True)
            continue
        force_staff = (cam["role"] == "backroom")
        print(f"[detect] {fname} -> {cam['camera_id']} (role={cam['role']})", flush=True)
        _process(model, os.path.join(clips_dir, fname), cam, store_id, emitter, force_staff)


def _process(model, clip_path, cam, store_id, emitter, force_staff):
    import cv2
    cap = cv2.VideoCapture(clip_path); fps = cap.get(cv2.CAP_PROP_FPS) or 25.0; cap.release()
    role = cam["role"]
    sessions = None
    if role == "entry_threshold":
        ln = cam["entry_line"]
        sessions = SessionManager(line_x=ln["normalised_position"],
                                  inbound_is_rightward=(ln["inbound_direction"] != "leftward"))
    zones = cam.get("covers_zones", [])
    bands = [(i/len(zones), (i+1)/len(zones), zones[i]) for i in range(len(zones))] if (zones and role in ("main_floor","billing")) else None
    visitor_zone = {}; zenter = {}
    fi = 0
    for result in model.track(source=clip_path, classes=[0], persist=True, stream=True,
                              tracker="bytetrack.yaml", verbose=False,
                              imgsz=INFER_IMGSZ, vid_stride=VID_STRIDE, conf=YOLO_CONF):
        ts = CLIP_START + timedelta(seconds=(fi*VID_STRIDE)/fps)
        fi += 1
        if fi % 50 == 0:
            print(f"  [{Path(clip_path).name}] {fi} frames, {len(visitor_zone)} active tracks", flush=True)
        if result.boxes is None or result.boxes.id is None:
            continue
        w = result.orig_shape[1]
        for box, tid, conf in zip(result.boxes.xywh, result.boxes.id, result.boxes.conf):
            cx = float(box[0])/w; track_id = int(tid); confidence = float(conf)
            if sessions is not None:
                for d in sessions.update(track_id, cx, ts):
                    emitter.emit(make_event(store_id=store_id, camera_id=cam["camera_id"],
                        visitor_id=d["visitor_id"], event_type=d["event_type"], timestamp=ts,
                        confidence=confidence, is_staff=force_staff, session_seq=d["session_seq"]))
            elif bands:
                vtok = f"TRK_{cam['camera_id']}_{track_id}"
                zone = next((n for lo,hi,n in bands if lo<=cx<hi), bands[-1][2])
                prev = visitor_zone.get(track_id)
                if zone != prev:
                    if prev is not None:
                        emitter.emit(make_event(store_id=store_id, camera_id=cam["camera_id"],
                            visitor_id=vtok, event_type="ZONE_EXIT", timestamp=ts, zone_id=prev,
                            confidence=confidence, is_staff=force_staff, sku_zone=prev))
                        zenter.pop((track_id,prev), None)
                    emitter.emit(make_event(store_id=store_id, camera_id=cam["camera_id"],
                        visitor_id=vtok, event_type="ZONE_ENTER", timestamp=ts, zone_id=zone,
                        confidence=confidence, is_staff=force_staff, sku_zone=zone))
                    zenter[(track_id,zone)] = ts; visitor_zone[track_id] = zone
                else:
                    et = zenter.get((track_id,zone), ts)
                    dwell = (ts-et).total_seconds()
                    if dwell >= 30 and int(dwell) % 30 == 0:
                        emitter.emit(make_event(store_id=store_id, camera_id=cam["camera_id"],
                            visitor_id=vtok, event_type="ZONE_DWELL", timestamp=ts, zone_id=zone,
                            dwell_ms=int(dwell*1000), confidence=confidence,
                            is_staff=force_staff, sku_zone=zone))


# ---------------- replay mode ----------------

def run_replay(events_path, emitter, realtime=False, speed=30.0):
    prev = None
    for line in open(events_path):
        if not line.strip():
            continue
        ev = json.loads(line)
        if realtime and prev is not None:
            cur = datetime.fromisoformat(ev["timestamp"].replace("Z","+00:00"))
            gap = (cur-prev).total_seconds()/speed
            if gap > 0: time.sleep(min(gap, 5.0))
            prev = cur
        elif realtime:
            prev = datetime.fromisoformat(ev["timestamp"].replace("Z","+00:00"))
        emitter.emit(ev)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["synth","video","replay"], default="synth")
    ap.add_argument("--store", default=None)
    ap.add_argument("--clips", default="..\\clips")
    ap.add_argument("--layout", default="store_layout.json")
    ap.add_argument("--out", default=None)
    ap.add_argument("--n", type=int, default=60)
    ap.add_argument("--replay", default=None)
    ap.add_argument("--realtime", action="store_true")
    ap.add_argument("--speed", type=float, default=30.0)
    args = ap.parse_args()
    layout = load_layout(args.layout)
    store_id = args.store or layout["store_id"]
    with EventEmitter(args.out) as emitter:
        if args.mode == "synth":
            run_synth(layout, emitter, store_id, n_visitors=args.n)
        elif args.mode == "video":
            run_video(args.clips, layout, store_id, emitter)
        else:
            if not args.replay: raise SystemExit("--mode replay needs --replay <file>")
            run_replay(args.replay, emitter, realtime=args.realtime, speed=args.speed)
    print("[detect] done.", flush=True)


if __name__ == "__main__":
    main()
